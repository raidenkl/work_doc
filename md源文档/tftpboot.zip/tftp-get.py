#!/usr/bin/env python3
# TFTP RRQ 诊断脚本：打印服务器回复包的原始内容
# 用法: python3 tftp-get.py <server> <filename> [outfile]
# 示例: python3 host-setup/tftp-get.py 10.255.200.150 rk3576-lubancat-generic-tftpboot.dtb /tmp/x.dtb
import socket
import sys

host, fn = sys.argv[1], sys.argv[2]
out = sys.argv[3] if len(sys.argv) > 3 else "/tmp/x.dtb"

s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.settimeout(5)
# RFC1350 RRQ: opcode=1, filename, 0, mode, 0
s.sendto(bytes([0, 1]) + fn.encode() + b"\0" + b"octet\0", (host, 69))
try:
    data, addr = s.recvfrom(2048)
except socket.timeout:
    print("TIMEOUT: no reply from %s:69" % host)
    sys.exit(1)

print("reply from %s:%d  len=%d" % (addr[0], addr[1], len(data)))
print("hex[:80]:", data[:80].hex(" "))
op = int.from_bytes(data[:2], "big") if len(data) >= 2 else -1
if op == 3:
    print("opcode 3 = DATA, block#", int.from_bytes(data[2:4], "big"))
    if len(data) > 4:
        remaining = [data[4:]]
        s.sendto(bytes([0, 4]) + data[2:4], addr)  # ACK block 1
        try:
            while True:
                d, _ = s.recvfrom(2048)
                if int.from_bytes(d[:2], "big") == 3:
                    blk = int.from_bytes(d[2:4], "big")
                    s.sendto(bytes([0, 4]) + d[2:4], addr)
                    if len(d) < 516:
                        break
                    remaining.append(d[4:])
                elif int.from_bytes(d[:2], "big") == 5:
                    print("ERROR packet:", d[4:].split(b"\0")[0].decode(errors="replace"))
                    sys.exit(1)
        except socket.timeout:
            pass
        body = b"".join(remaining)
        open(out, "wb").write(body)
        print("OK: %d bytes -> %s" % (len(body), out))
elif op == 5:
    print("opcode 5 = ERROR code", int.from_bytes(data[2:4], "big"),
          "msg:", data[4:].split(b"\0")[0].decode(errors="replace"))
elif op == 6:
    print("opcode 6 = OACK:", data[2:])
else:
    print("opcode %d (unexpected) — raw dump above" % op)
