# LubanCat 3（RK3576）U-Boot 网络引导内核 移植与使用指南

> 实测环境：板卡 LubanCat 3 / RK3576，U-Boot 阶段 TFTP 拉取内核 43MB 完整下载（4.7 MiB/s），`booti` 启动成功。
> 本方案**零改动 SDK 原有文件**（团队维护友好），全部为新增文件。

---

## 1. 背景与原理

### 1.1 U-Boot 的两级设备树机制（为什么改内核 DTS 就能让 U-Boot 有网卡）

- **第一级**：U-Boot 自带 DTB（`CONFIG_DEFAULT_DEVICE_TREE`，如 `rk3576-evb`），打包在 `uboot.img` 里，仅用于最早期的串口/MMC/PMIC 初始化。
- **第二级（决定实际功能）**：`board_init()` → `init_kernel_dtb()`（`arch/arm/mach-rockchip/kernel_dtb.c`）接管内核设备树：
  - 查找顺序（`boot_rkimg.c: rockchip_read_dtb_file`）：
    1. **bootable 分区文件系统里的 `rk-kernel.dtb`**（extboot 模式命中此项）
    2. resource.img
    3. FIT 镜像内 dtb
    4. 内嵌 dtb 兜底
  - 校验通过后 `gd->fdt_blob` 切换为内核 dtb，重建设备模型；V2 流程（`dm_rm_u_boot_dev`）会**删除 U-Boot 自建的 ETH 设备、改用内核 dtb 里的网口节点**。
  - 这份 dtb（`fdt_addr_r`）就是最终 `booti` 传给内核的那份。

**结论**：内核 DTS 里 gmac0 = okay，则 U-Boot 阶段和内核阶段都有以太网，无需重编 U-Boot。

### 1.2 为什么需要派生 DTS（首启问题）

- SDK 的 `boot.img` 是 extboot 模式（128MB ext2），根目录的 `rk-kernel.dtb` 是 `rk3576-lubancat-generic.dtb` 的**实体文件**，其中 gmac0/gmac1 均为 `disabled`。
- 首次开机进系统后，`/etc/init.d/boot_init.sh` 会按 ADC 板级 ID 把 `/boot/rk-kernel.dtb` 软链切换为 `dtb/rk3576-lubancat-3.dtb`（gmac0=okay）并重启——**此后** U-Boot 网络天然可用。
- 但**第一次开机**就要网络引导时，U-Boot 读到的还是 generic 实体文件（无网卡）。解决：新建派生 DTS 使能 gmac0，通过新的设备 defconfig 引用，不修改原文件。

### 1.3 裸 Image 必须用 `booti` 启动

板上固件的 `tftpboot` 命令是 Rockchip 定制的 **tftpbootm**（下载完自动执行 `bootm`）。`bootm` 只认 uImage/FIT/Android 带头格式，解析裸 arm64 `Image` 会报 `ERROR: can't get kernel image!`（无害，下载已完成）。裸 Image 用 **`booti`**；纯下载用 **`tftp`** 命令。

---

## 2. SDK 侧改动（3 个新增文件，原文件零修改）

| 文件 | 作用 |
|---|---|
| `kernel-6.1/arch/arm64/boot/dts/rockchip/rk3576-lubancat-generic-tftpboot.dts` | 派生设备树：include 原 generic DTS + 使能 gmac0（ETH0，RTL8211F，tx_delay=0x05/rx_delay=0x05） |
| `device/rockchip/rk3576/LubanCat_rk3576_ubuntu_gnome_tftpboot_defconfig` | 新构建配置：基于 ubuntu_gnome 原版，`RK_KERNEL_DTS_NAME` 指向派生 DTS，增加内核配置碎片 |
| `kernel-6.1/arch/arm64/configs/lubancat_rk3576_tftpboot.config` | 内核配置碎片：`CONFIG_IP_PNP/IP_PNP_DHCP/ROOT_NFS`（仅 NFS root 方式需要，eMMC root 可忽略，保留无副作用） |

### 2.1 文件 1：派生设备树 `rk3576-lubancat-generic-tftpboot.dts`

**完整内容**：

```dts
// SPDX-License-Identifier: (GPL-2.0+ OR MIT)
/*
 * Derived from rk3576-lubancat-generic.dts: enable gmac0 so that U-Boot
 * (USING_KERNEL_DTB_V2) can bring up Ethernet on the FIRST boot for
 * TFTP network booting of the kernel.
 *
 * Copyright (c) 2024 EmbedFire <embedfire@embedfire.com>
 */

#include "rk3576-lubancat-generic.dts"

&mdio0 {
	rgmii_phy0: phy@0 {
		compatible = "ethernet-phy-ieee802.3-c22";
		reg = <0x0>;
		clocks = <&cru REFCLKO25M_GMAC0_OUT>;

		realtek,led-data = <0x6d60>;  //8211F phy
	};
};

&gmac0 {
	/* Use rgmii-rxid mode to disable rx delay inside Soc */
	phy-mode = "rgmii-rxid";
	clock_in_out = "output";

	snps,reset-gpio = <&gpio3 RK_PB7 GPIO_ACTIVE_LOW>;
	snps,reset-active-low;
	/* Reset time is 20ms, 100ms for rtl8211f */
	snps,reset-delays-us = <0 20000 100000>;

	pinctrl-names = "default";
	pinctrl-0 = <&eth0m0_miim
			&eth0m0_tx_bus2
			&eth0m0_rx_bus2
			&eth0m0_rgmii_clk
			&eth0m0_rgmii_bus
			&eth0m0_mclk>;

	tx_delay = <0x05>;
	rx_delay = <0x05>;

	phy-handle = <&rgmii_phy0>;
	status = "okay";
};
```

**修改理由**：

1. **为什么需要它**：首启时 U-Boot 从 boot 分区加载的 `rk-kernel.dtb` 是 `rk3576-lubancat-generic.dtb` 的实体文件，其中 gmac0/gmac1 均 `disabled`（`fdtget` 实测确认），U-Boot 阶段没有网卡，网络引导无从谈起。而首启后 `boot_init.sh` 才会把软链切到 `rk3576-lubancat-3.dtb`（gmac0=okay）——首启网络引导必须让 generic 这份 dtb 也带上网口。
2. **为什么用派生而不是直接改**：`rk3576-lubancat-generic.dts` 是团队维护的文件。DTS 支持 `#include` 文本包含，本文件引用原文件后通过 `&mdio0` / `&gmac0` 追加节点（设备树合并语义：同名节点属性覆盖、新节点追加），等价于"原地修改"但原文件保持不动。注意：原文件已含 `/dts-v1/;`，派生文件**不能**重复声明（cpp 文本包含会带入，重复会编译报错）。
3. **参数来源**：gmac0 使能段与 `rk3576-lubancat-3.dts`（LubanCat 3 官方板级 DTS，627~670 行）完全一致——同一 SoC 的 gmac0 使用相同的 m0 引脚复用组（`eth0m0_*`）与 RTL8211F PHY，延时参数（tx_delay=0x05/rx_delay=0x05）沿用官方验证值。
4. **关键属性说明**：
   - `phy-mode = "rgmii-rxid"`：RX 延时由 PHY 侧处理，SoC 侧只调 `rx_delay`；
   - `snps,reset-gpio/reset-active-low/reset-delays-us`：PHY 复位时序（20ms 保持 + 100ms 等待），U-Boot 的 `drivers/net/dwc_eth_qos.c:1894-1903` 会解析这三个属性；
   - `clocks = <&cru REFCLKO25M_GMAC0_OUT>`：给 PHY 提供 25MHz 参考时钟；
   - `realtek,led-data`：RTL8211F 指示灯行为配置。

5. **生效链路**：`do_build_extboot`（`device/rockchip/common/scripts/mk-kernel.sh`）执行 `$KMAKE "$RK_KERNEL_DTS_NAME.img"`（`arch/arm64/Makefile:219` 的 `%.img` 规则，无需在 rockchip dts Makefile 注册 dtb），并把 `<RK_KERNEL_DTS_NAME>.dtb` 拷贝为 boot 分区根目录的 `rk-kernel.dtb` → 首次开机 U-Boot 即加载到带网卡的 dtb。

### 2.2 文件 2：构建配置 `LubanCat_rk3576_ubuntu_gnome_tftpboot_defconfig`

**完整内容**：

```
# RK_BUILDROOT is not set
# RK_YOCTO is not set
RK_ROOTFS_SYSTEM_UBUNTU=y
RK_ROOTFS_IMAGE="ubuntu-${RK_CHIP}-${RK_ROOTFS_TARGET}-rootfs.img"
# RK_WIFIBT is not set
RK_UBOOT_SPL=y
RK_KERNEL_PREFERRED="6.1"
RK_KERNEL_CFG="lubancat_linux_rk3576_defconfig"
RK_KERNEL_CFG_FRAGMENTS="lubancat_rk3576_tftpboot.config"
RK_KERNEL_DTS_NAME="rk3576-lubancat-generic-tftpboot"
RK_KERNEL_EXTBOOT=y
# RK_RECOVERY is not set
RK_EXTRA_PARTITION_NUM=0
RK_PARAMETER="parameter-extboot.txt"
RK_USE_FIT_IMG=y
RK_PACKAGE_FILE_CUSTOM=y
RK_PACKAGE_FILE="package-file-extboot"
RK_PACKAGE_NAME="lubancat-${RK_CHIP}-${RK_UBUNTU_NUMBER}-${RK_ROOTFS_TARGET}-$(date +%Y%m%d)"
```

**修改理由**：

1. **为什么新建而不改原 defconfig**：`LubanCat_rk3576_ubuntu_gnome_defconfig` 是团队维护文件；SDK 根 Makefile 有 `$(CHIP_DIR)/%_defconfig` 模式规则，新文件放入 `device/rockchip/rk3576/` 即可被 `make <名字>_defconfig` 识别，天然支持多配置并存。
2. **与原版的差异仅 2 行**（`diff` 可证）：
   - `RK_KERNEL_DTS_NAME="rk3576-lubancat-generic-tftpboot"`：SDK 用这个名字完成三件事——`make <名字>.img` 构建内核+dtb、`do_build_extboot` 将对应 dtb 拷为 boot 分区的 `rk-kernel.dtb`（决定首启 U-Boot 的设备树）、生成 `RK_KERNEL_DTB`。指向派生 DTS 即让首启固件带网卡。
   - 新增 `RK_KERNEL_CFG_FRAGMENTS="lubancat_rk3576_tftpboot.config"`：引用内核配置碎片（见文件 3）。
3. **碎片机制是 SDK 正式能力**：`RK_KERNEL_CFG_FRAGMENTS` 是 SDK 的 Kconfig 符号（`device/rockchip/common/configs/Config.in.kernel:43`）；构建时 `mk-kernel.sh` 的 `do_make_kernel_config` 把它作为额外 make 目标传入：`make lubancat_linux_rk3576_defconfig lubancat_rk3576_tftpboot.config`，由内核 `scripts/kconfig/Makefile:96-101` 的 `%.config` 规则调用 `merge_config.sh -m .config <fragment>` 后 `olddefconfig` 合并，碎片文件位于 `arch/arm64/configs/` 即可被找到。Rockchip 自家 defconfig 同样在用（如 `rockchip_rk3562_robot_evb1_lp4x_v10_defconfig` 中的 `RK_KERNEL_CFG_FRAGMENTS="rk3562_robot.config"`）。
4. **为什么以 ubuntu_gnome 为基线**：按需求指定（Ubuntu GNOME rootfs）；其余选项（extboot、parameter-extboot 等）与原版保持一致，保证与现有烧录/分区方案兼容。

### 2.3 文件 3：内核配置碎片 `lubancat_rk3576_tftpboot.config`

**完整内容**：

```
CONFIG_IP_PNP=y
CONFIG_IP_PNP_DHCP=y
CONFIG_ROOT_NFS=y
```

**修改理由**：

1. **为什么需要**：实测 SDK 当前内核 `.config` 中 `# CONFIG_IP_PNP is not set`（`CONFIG_ROOT_NFS` 同样未开启）。这意味着 NFS root 启动方式下，内核命令行的 `ip=dhcp`、`root=/dev/nfs` 会被**直接忽略**（`ip=` 参数属于 IP 内核级自动配置子系统），NFS root 无法工作。三项的作用：
   - `CONFIG_IP_PNP`：内核级 IP 自动配置框架（解析 `ip=` 参数）；
   - `CONFIG_IP_PNP_DHCP`：自动配置的 DHCP 实现；
   - `CONFIG_ROOT_NFS`：把 NFS 作为根文件系统挂载。
   （`NFS_FS/SUNRPC/LOCKD` 已内建，无需重复添加。）
2. **为什么用碎片文件**：正式的内核 defconfig `lubancat_linux_rk3576_defconfig` 是团队维护文件，直接修改会在下次 `savedefconfig` 时产生冲突。碎片文件是独立新文件，随本 defconfig 生效，不污染原配置。
3. **适用范围**：仅 **NFS root** 方式需要。eMMC root 方式（root=/dev/mmcblk0p3）不依赖这三项；保留它们对正常启动无副作用（无 `ip=` 参数时 IP-PNP 不做任何事）。
4. **维护提示**：若日后需要调整内核配置，正式改动都放进本碎片文件；**不要**执行 `./build.sh kernel-config`——它会 `savedefconfig` 回写原始 `lubancat_linux_rk3576_defconfig`，破坏"原文件零改动"约束。

### 2.4 构建与烧录

```shell
cd ~/LubanCat_SDK
 # 选择新配置
./build.sh chip                                       # 选择对应的配置（rk-kernel.dtb 为 gmac0 使能版）
./build.sh                                              # 继续构建 rootfs / updateimg（按需）

```

产物位置：
- 内核：`kernel-6.1/arch/arm64/boot/Image`
- 设备树：`kernel-6.1/arch/arm64/boot/dts/rockchip/rk3576-lubancat-generic-tftpboot.dtb`（首启用）、`rk3576-lubancat-3.dtb`（首启后 U-Boot 实际加载）

> ⚠️ 注意：**不要**执行 `./build.sh kernel-config`（它会 `savedefconfig` 回写原始内核 defconfig）。临时调内核配置用 `make -C kernel menuconfig`，正式改动放碎片文件。

---

## 3. 主机侧准备（TFTP 服务）

### 3.1 网络拓扑（实测）

| 端 | 地址 | 说明 |
|---|---|---|
| 主机 | `10.255.200.150`（ens160） | 与板卡网段已路由互通 |
| 板卡 | `192.168.103.143` 静态 | 网关 `192.168.103.254` |
| TFTP | dnsmasq 纯 TFTP 模式 | **无 DNS、无 DHCP**，不影响办公网 |

### 3.2 文件准备

```shell
cd ~/LubanCat_SDK
cp kernel-6.1/arch/arm64/boot/Image tftpboot/
cp kernel-6.1/arch/arm64/boot/dts/rockchip/rk3576-lubancat-generic-tftpboot.dtb tftpboot/
cp kernel-6.1/arch/arm64/boot/dts/rockchip/rk3576-lubancat-3.dtb tftpboot/
chmod -R o+r tftpboot/          # dnsmasq 降权运行，需要全员可读
```

> 重编内核后记得重新拷贝 Image。不要用 `kernel-6.1/extboot/rk-kernel.dtb`（generic、无网口）。

### 3.3 TFTP 服务（dnsmasq 纯 TFTP，无需安装新包）

配置文件 `host-setup/lubancat-tftp.conf`（已就绪）：

```
port=0                     # 关闭 DNS
interface=ens160           # 只绑主机出口网卡
bind-dynamic
enable-tftp
tftp-root=/home/dev/ljh/server_dev/LubanCat_SDK/tftpboot
pid-file=/run/lubancat-tftpd.pid
```

安装并启动（一次性）：

```shell
cd ~/LubanCat_SDK
sudo cp host-setup/lubancat-tftpd.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now lubancat-tftpd
ss -ulnp | grep :69        # 验证监听
```

服务管理：

```shell
sudo systemctl status|stop|restart lubancat-tftpd
sudo dnsmasq -d -C host-setup/lubancat-tftp.conf      # 前台调试（实时日志）
```

### 3.4 主机自测

```shell
# python 脚本（推荐，能打印回复包详情）：
python3 host-setup/tftp-get.py 10.255.200.141 rk3576-lubancat-generic-tftpboot.dtb /tmp/x.dtb
# curl 可用但挑剔（失败不代表服务端有问题，以板端 U-Boot 为准）：
curl -v --tftp-no-options tftp://10.255.200.150/rk3576-lubancat-generic-tftpboot.dtb -o /tmp/x.dtb
```

---

## 4. 板卡端操作（U-Boot 命令）

### 4.1 进入 U-Boot 命令行

串口 **1500000 8N1**，上电瞬间**按住 Ctrl+C**（Rockchip 在 BOOTDELAY=0 下仍响应 ctrlc()）。
日志确认：`DTB(Distro): rk-kernel.dtb`、`DM: v2`。

### 4.2 网络配置与下载（实测参数）

```shell
setenv ipaddr 192.168.103.143        # 板卡 IP（独立网段静态地址）
setenv netmask 255.255.255.0
setenv gatewayip 192.168.103.254     # 必须设置，跨网段到主机靠它
setenv serverip 10.255.200.150       # 主机（TFTP 服务器）
saveenv                              # 若 env 不持久则每次重设
ping ${serverip}
```

### 4.3 下载并启动

```shell
tftp ${kernel_addr_r} Image                                  # 内核 → 0x40400000
tftp ${fdt_addr_r} rk3576-lubancat-3.dtb      # 设备树 → 0x48300000
setenv bootargs "console=ttyFIQ0,1500000 console=tty1 rw rootwait root=/dev/mmcblk0p3 rootfstype=ext4"
booti ${kernel_addr_r} - ${fdt_addr_r}
```

成功标志：`Bytes transferred = 43188736` → booti 后内核串口正常输出 → eMMC rootfs 登录。

### 4.4 NFS root 变体（可选，需内核碎片生效）

```shell
setenv bootargs "console=ttyFIQ0,1500000 console=tty1 rw rootwait root=/dev/nfs \
 nfsroot=${serverip}:/srv/nfs/lubancat-rootfs,v3,tcp \
 ip=${ipaddr}:${serverip}:${gatewayip}:${netmask}:lubancat:eth0:off"
booti ${kernel_addr_r} - ${fdt_addr_r}
```

> 主机需导出 rootfs：`/etc/exports` 加 `/srv/nfs/lubancat-rootfs 10.255.200.0/24(rw,sync,no_root_squash,no_subtree_check)` 后 `sudo exportfs -ra`。

---

## 5. 常见问题

| 现象 | 原因与对策 |
|---|---|
|
| U-Boot 首启无网卡 | 确认烧录的是含 `rk3576-lubancat-generic-tftpboot.dtb` 的 boot.img；U-Boot 日志应显示 `DTB(Distro): rk-kernel.dtb` |
| ping 不通 | 插 **ETH0**（gmac0）；gatewayip 是否正确；跨网段 ACL |
| TFTP 超时 | 中间防火墙拦 UDP 69/高位回包端口；可在 conf 加 `tftp-no-blocksize`；`sudo tcpdump -ni any udp port 69` 抓包定位 |
| 首启后自动重启一次 | 正常：`boot_init.sh` 切换 `rk-kernel.dtb` 软链到板级 dtb 并重启；之后网络能力不变 |
| curl 下载异常 | curl TFTP 客户端挑剔，以 `tftp-get.py` 和板端 U-Boot 实测为准 |

---

## 6. 文件清单

```
LubanCat_SDK/
├── host-setup/
│   ├── lubancat-tftp.conf          # dnsmasq 纯 TFTP 配置（新增）
│   ├── lubancat-tftpd.service      # systemd 单元（新增）
│   ├── tftp-get.py                 # TFTP 诊断脚本（新增）
│   └── uboot-tftpboot-guide.md     # 本文档
├── tftpboot/                       # TFTP 根目录（Image + 2 个 dtb）
├── device/rockchip/rk3576/
│   └── LubanCat_rk3576_ubuntu_gnome_tftpboot_defconfig   # 新构建配置
└── kernel-6.1/
    ├── arch/arm64/boot/dts/rockchip/rk3576-lubancat-generic-tftpboot.dts  # 派生 DTS
    └── arch/arm64/configs/lubancat_rk3576_tftpboot.config                 # 内核配置碎片
```

