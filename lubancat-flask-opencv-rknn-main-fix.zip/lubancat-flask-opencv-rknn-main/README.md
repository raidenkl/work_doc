# 鲁班猫监控检测示例

详细介绍参考[教程](https://doc.embedfire.com/linux/rk356x/Python/zh/latest/example/camera_demo.html)。


# 参考

https://github.com/miguelgrinberg/flask-video-streaming

https://gitee.com/Embedfire/flask-video-streaming-recorder

https://github.com/rockchip-linux/rknn-toolkit2

